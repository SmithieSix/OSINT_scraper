import requests
from bs4 import BeautifulSoup

def scrape_news_sites(urls, keywords):
    results = []
    headers = {"User-Agent": "Mozilla/5.0"}
    
    for url in urls:
        try:
            response = requests.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, "html.parser")
            for link in soup.find_all("a"):
                title = link.get_text()
                href = link.get("href", "")
                if any(k.lower() in title.lower() for k in keywords):
                    results.append({"source": url, "title": title, "link": href})
        except Exception as e:
            print(f"Error scraping {url}: {e}")
    
    return results